import { useEffect, useRef, useState } from "react";
import "./App.css";

function App() {
  const [count, setCount] = useState(0);
  let id;

  useEffect(() => {
    id = setInterval(() => {
      setCount(count + 1);
    }, 1000);

    return () => {
      clearInterval(id);
    };
  }, [count, id]);
  return (
    <div className="App">
      <h1>{count}</h1>
      <button onClick={()=>setCheck(true)}>start</button>
      <button onClick={()=>setCheck(false)}>stop</button>
      <button onClick={()=>setCheck(true)}>clear</button>
    </div>
  );
}

export default App;
